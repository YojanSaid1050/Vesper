const verifyButton =
  require('../../handlers/verifyButton');

const dashboardButtons =
  require('../../handlers/dashboardButtons');

const dashboardSelects =
  require('../../handlers/dashboardSelects');

const dashboardModals =
  require('../../handlers/dashboardModals');

const {
  Events
} = require('discord.js');

module.exports = {

  name:
    Events.InteractionCreate,

  async execute(
    interaction,
    client
  ) {
console.log(
  '[ROUTER]',
  interaction.type,
  interaction.customId ||
  interaction.commandName
);
    try {

      // ==========================
      // COMMANDS
      // ==========================

      if (
        interaction.isChatInputCommand()
      ) {

        const command =
          client.commands.get(
            interaction.commandName
          );

        if (command) {

          await command.execute(
            interaction,
            client
          );

        }

        return;

      }

      // ==========================
      // BUTTONS
      // ==========================

      if (
        interaction.isButton()
      ) {

        if (
          interaction.customId ===
          'verify_void'
        ) {

          return verifyButton(
            interaction
          );

        }

        if (
          interaction.customId.startsWith(
            'dashboard_'
          )
        ) {

          return dashboardButtons(
            interaction
          );

        }

      }

      // ==========================
      // SELECTS
      // ==========================

      if (
        interaction.isChannelSelectMenu()
      ) {

        return dashboardSelects(
          interaction
        );

      }

      // ==========================
      // MODALS
      // ==========================

      if (
        interaction.isModalSubmit()
      ) {

        return dashboardModals(
          interaction
        );

      }

    }

    catch (error) {

      console.error(error);

    }

  }

};