const {
  updateGuildSection
} = require('../utils/guildManager');

const brandingPanel =
  require('../functions/Embeds/dashboard/brandingPanel');

module.exports =
  async function dashboardModals(
    interaction
  ) {

    try {

      console.log(
        '[MODAL]',
        interaction.customId
      );

      const guildId =
        interaction.guild.id;

      switch (
        interaction.customId
      ) {

        case 'branding_name_modal':

          updateGuildSection(

            guildId,

            'branding',

            {
              serverName:
                interaction.fields.getTextInputValue(
                  'server_name'
                )
            }

          );

          return interaction.update(
            brandingPanel(
              guildId
            )
          );

        case 'branding_footer_modal':

          updateGuildSection(

            guildId,

            'branding',

            {
              footer:
                interaction.fields.getTextInputValue(
                  'footer_text'
                )
            }

          );

          return interaction.update(
            brandingPanel(
              guildId
            )
          );

      }

    }

    catch (error) {

      console.error(
        '❌ Error dashboardModals'
      );

      console.error(error);

    }

  };