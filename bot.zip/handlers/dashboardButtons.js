const mainPanel =
  require('../functions/Embeds/dashboard/mainPanel');

const generalPanel =
  require('../functions/Embeds/dashboard/generalPanel');

const botPanel =
  require('../functions/Embeds/dashboard/botPanel');

const brandingPanel =
  require('../functions/Embeds/dashboard/brandingPanel');

const testPanel =
  require('../functions/Embeds/dashboard/testPanel');

module.exports =
  async function dashboardButtons(
    interaction
  ) {

    try {

      console.log(
        '[BUTTON]',
        interaction.customId
      );

      let panel = null;

      switch (
        interaction.customId
      ) {

        case 'dashboard_home':

          panel =
            mainPanel();

          break;

        case 'dashboard_general':

          panel =
            generalPanel(
              interaction.guild.id
            );

          break;

        case 'dashboard_bot':

          panel =
            botPanel(
              interaction.guild.id
            );

          break;

        case 'dashboard_branding':

          panel =
            brandingPanel(
              interaction.guild.id
            );

          break;

        case 'dashboard_tests':

          panel =
            testPanel();

          break;

      }

      if (!panel) {

        return;

      }

      await interaction.update(
        panel
      );

    }

    catch (error) {

      console.error(
        '❌ Error dashboardButtons'
      );

      console.error(error);

    }

  };