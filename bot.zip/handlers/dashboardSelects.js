const {
  updateGuildSection
} = require('../utils/guildManager');

const generalPanel =
  require('../functions/Embeds/dashboard/generalPanel');

module.exports =
  async function dashboardSelects(
    interaction
  ) {

    try {

      console.log(
        '[SELECT]',
        interaction.customId
      );

      const guildId =
        interaction.guild.id;

      const channelId =
        interaction.values[0];

      switch (
        interaction.customId
      ) {

        case 'general_welcome':

          updateGuildSection(

            guildId,

            'general',

            {
              welcomeChannel:
                channelId
            }

          );

          break;

        case 'general_goodbye':

          updateGuildSection(

            guildId,

            'general',

            {
              goodbyeChannel:
                channelId
            }

          );

          break;

        case 'general_log':

          updateGuildSection(

            guildId,

            'general',

            {
              logChannel:
                channelId
            }

          );

          break;

        default:

          return;

      }

      await interaction.update(
        generalPanel(
          guildId
        )
      );

    }

    catch (error) {

      console.error(
        '❌ Error dashboardSelects'
      );

      console.error(error);

    }

  };