module.exports =
  guildId => ({

    content:
      '🎨 Configuración Branding en construcción'

  });