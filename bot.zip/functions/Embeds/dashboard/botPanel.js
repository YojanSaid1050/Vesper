module.exports =
  guildId => ({

    content:
      '🤖 Configuración Bot en construcción'

  });