const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType
} = require('discord.js');

const {
  getGuildConfig
} = require('../../../utils/guildManager');

module.exports = guildId => {

  const config =
    getGuildConfig(guildId);

  const embed =
    new EmbedBuilder()

      .setTitle(
        '📢 Configuración General'
      )

      .setColor(
        0x5865F2
      )

      .addFields(

        {
          name: '👋 Welcome',
          value:
            config.general.welcomeChannel
              ? `<#${config.general.welcomeChannel}>`
              : 'No configurado'
        },

        {
          name: '👋 Goodbye',
          value:
            config.general.goodbyeChannel
              ? `<#${config.general.goodbyeChannel}>`
              : 'No configurado'
        },

        {
          name: '📜 Logs',
          value:
            config.general.logChannel
              ? `<#${config.general.logChannel}>`
              : 'No configurado'
        }

      );

  const welcomeRow =
    new ActionRowBuilder()

      .addComponents(

        new ChannelSelectMenuBuilder()

          .setCustomId(
            'general_welcome'
          )

          .setPlaceholder(
            'Seleccionar canal Welcome'
          )

          .addChannelTypes(
            ChannelType.GuildText
          )

      );

  const goodbyeRow =
    new ActionRowBuilder()

      .addComponents(

        new ChannelSelectMenuBuilder()

          .setCustomId(
            'general_goodbye'
          )

          .setPlaceholder(
            'Seleccionar canal Goodbye'
          )

          .addChannelTypes(
            ChannelType.GuildText
          )

      );

  const logsRow =
    new ActionRowBuilder()

      .addComponents(

        new ChannelSelectMenuBuilder()

          .setCustomId(
            'general_log'
          )

          .setPlaceholder(
            'Seleccionar canal Logs'
          )

          .addChannelTypes(
            ChannelType.GuildText
          )

      );

  const buttons =
    new ActionRowBuilder()

      .addComponents(

        new ButtonBuilder()

          .setCustomId(
            'dashboard_home'
          )

          .setLabel(
            'Volver'
          )

          .setStyle(
            ButtonStyle.Secondary
          )

      );

  return {

    embeds: [embed],

    components: [

      welcomeRow,

      goodbyeRow,

      logsRow,

      buttons

    ]

  };

};