const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');

module.exports = () => {

  const embed =
    new EmbedBuilder()

      .setTitle(
        '⚙️ Configuración del Servidor'
      )

      .setDescription(

        [
          'Gestiona toda la configuración del bot desde este panel.',
          '',
          '📢 **General**',
          'Canales de bienvenida, despedida y logs.',
          '',
          '🤖 **Bot**',
          'Configuración del rol del bot.',
          '',
          '🎨 **Branding**',
          'Nombre y avatar personalizados.',
          '',
          '🧪 **Tests**',
          'Pruebas de mensajes.'
        ].join('\n')

      )

      .setColor(
        0x5865F2
      );

  const row =
    new ActionRowBuilder()

      .addComponents(

        new ButtonBuilder()

          .setCustomId(
            'dashboard_general'
          )

          .setLabel(
            'General'
          )

          .setEmoji(
            '📢'
          )

          .setStyle(
            ButtonStyle.Primary
          ),

        new ButtonBuilder()

          .setCustomId(
            'dashboard_bot'
          )

          .setLabel(
            'Bot'
          )

          .setEmoji(
            '🤖'
          )

          .setStyle(
            ButtonStyle.Secondary
          ),

        new ButtonBuilder()

          .setCustomId(
            'dashboard_branding'
          )

          .setLabel(
            'Branding'
          )

          .setEmoji(
            '🎨'
          )

          .setStyle(
            ButtonStyle.Success
          ),

        new ButtonBuilder()

          .setCustomId(
            'dashboard_tests'
          )

          .setLabel(
            'Tests'
          )

          .setEmoji(
            '🧪'
          )

          .setStyle(
            ButtonStyle.Danger
          )

      );

  return {

    embeds: [embed],

    components: [row]

  };

};